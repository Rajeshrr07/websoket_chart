import React from 'react';
import { useLocation } from 'react-router-dom';
import LineChart from '../components/Charts/LineChart';
import BarChart from '../components/Charts/BarChart';
import PieChart from '../components/Charts/PieChart';
import useWebSocket from '../hooks/useWebSocket';
import WebSocketAlert from '../components/WebSocketAlert';
import useOrderBookStore from '../store/orderBookStore';

const DetailsPage = () => {
  const location = useLocation();
  const { chartType } = location.state;

  const { orderBook, buyDetails, sellDetails, connectionStatus } = useOrderBookStore((state) => ({
    orderBook: state.orderBook,
    buyDetails: state.buyDetails,
    sellDetails: state.sellDetails,
    connectionStatus: state.connectionStatus,
  }));
 

  useWebSocket('ws://localhost:8080');

 
  const mapToChartData = (volumes, orders) => {
    if (!volumes || !orders || volumes.length !== orders.length) return [];
    return volumes.map((volume, index) => ({
      price: orders[index],
      volume: parseFloat(volume),
    }));
  };


  const formattedBidData = Array.isArray(orderBook.bids) ? orderBook.bids : [];
  const formattedAskData = Array.isArray(orderBook.asks) ? orderBook.asks : [];
  const formattedBuyData = mapToChartData(buyDetails?.totalVolume || [], buyDetails?.totalOrders || []);
  const formattedSellData = mapToChartData(sellDetails?.totalVolume || [], sellDetails?.totalOrders || []);

 

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <WebSocketAlert status={connectionStatus} />
      <h1 className="text-3xl font-bold mb-6 text-center">Order Book Visualizations</h1>
      <p className="text-center text-gray-600 mb-8">Explore bid, ask, buy, and sell data with interactive charts.</p>
      {!orderBook?<p>Loading</p>:(
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white shadow-lg rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4 text-center">Bids Data</h2>
          {chartType === 'bar' && <BarChart data={formattedBidData} />}
          {chartType === 'line' && <LineChart data={formattedBidData} />}
          {chartType === 'pie' && <PieChart data={formattedBidData} />}
        </div>

        <div className="bg-white shadow-lg rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4 text-center">Asks Data</h2>
          {chartType === 'bar' && <BarChart data={formattedAskData} />}
          {chartType === 'line' && <LineChart data={formattedAskData} />}
          {chartType === 'pie' && <PieChart data={formattedAskData} />}
        </div>

        <div className="bg-white shadow-lg rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4 text-center text-green-500">Buy Details</h2>
          {chartType === 'bar' && <BarChart data={formattedBuyData} />}
          {chartType === 'line' && <LineChart data={formattedBuyData} />}
          {chartType === 'pie' && <PieChart data={formattedBuyData} />}
        </div>

        <div className="bg-white shadow-lg rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4 text-center text-red-500">Sell Details</h2>
          {chartType === 'bar' && <BarChart data={formattedSellData} />}
          {chartType === 'line' && <LineChart data={formattedSellData} />}
          {chartType === 'pie' && <PieChart data={formattedSellData} />}
        </div>
      </div>
      )}

      
    </div>
  );
};

export default DetailsPage;
